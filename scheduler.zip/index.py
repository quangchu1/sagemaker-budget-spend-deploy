import boto3
import os

def handler(event, context):
    sagemaker = boto3.client('sagemaker')
    notebook_name = os.environ['NOTEBOOK_NAME']
    action = event.get('action', 'start')
    
    try:
        if action == 'start':
            sagemaker.start_notebook_instance(NotebookInstanceName=notebook_name)
            return {'statusCode': 200, 'body': f'Started {notebook_name}'}
        elif action == 'stop':
            sagemaker.stop_notebook_instance(NotebookInstanceName=notebook_name)
            return {'statusCode': 200, 'body': f'Stopped {notebook_name}'}
    except Exception as e:
        return {'statusCode': 500, 'body': str(e)}
